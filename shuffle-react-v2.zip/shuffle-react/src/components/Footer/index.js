import logo from "../../assets/img/teya-logo.png";
import './index.css';

const FooterMediaIconList = [
    {
      src: "https://bisoswap.com/_next/static/media/icon_tele.9ad431b9.png",
      key: "1",
    },
    {
      src: "https://bisoswap.com/_next/static/media/icon_tw.149da19b.png",
      key: "2",
    },
    {
      src: logo,
      key: "1",
    },
    {
      src: "https://bisoswap.com/_next/static/media/icon_medium.4c0e8d75.png",
      key: "1",
    },
    {
      src: "https://bisoswap.com/_next/static/media/icon_gitbook.045d29fb.png",
      key: "1",
    },
  ];

function Footer(list = FooterMediaIconList) {
    return(
          <div className='media-list'>
          {FooterMediaIconList.map((mediaItem) => {
              return (
                <div className="media-item-wrapper">
                  <img
                    src={mediaItem.src}
                    className="media_pic_item"
                    alt="logo"
                  />
                </div>
              );
              })}
          </div>
      );
  }

export default Footer;
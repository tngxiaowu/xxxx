import './index.css';
import logo from '../../assets/img/teya-logo.png';
import step1 from "../../assets/img/how-it-works-1.png";
import step2 from "../../assets/img/how-it-works-2.png";
import step3 from "../../assets/img/how-it-works-3.png";



const DefaultWalletList = [
    {
        name: 'connect wallet 1',
        key: '1',
    },
    {
        name: 'connect wallet 2',
        key: '2',
    }
];

const FooterMediaIconList = [
  {
    src: "1",
    key: "1",
  },
  {
    src: "2",
    key: "2",
  },
  {
    src: logo,
    key: "1",
  },
  {
    src: "4",
    key: "1",
  },
  {
    src: "5",
    key: "1",
  },
];

function WalletItem({ wallet }) {
    return (
        <div className='wallet-item'>
            {wallet.name}
        </div>
    )
}

function Header({ walletList = DefaultWalletList }) {
  return (
    <div className='header-view'>
      <div className='teya-logo-item'>
         <img src={logo} alt="logo" />
      </div>
      <div className='wallet-list'>
        {walletList.map((walletItem) => {
            return <WalletItem wallet={walletItem} />;
      })}</div>
    </div>
  );
}

function MainTitle() {
    return (
      <div className='main-title'>
        <div className='main-title_title'> TEYA - the first AMM DEX in the BRC20 ecosystem! </div>
        <div className='main-title_content'>
            Add liquidity, gain to transaction fees and enjoy a lower GAS experience!
        </div>
      </div>
    );
}

function HowItWork() {
    return (
      <div className="how-it-work">
        <div className="how-it-work_title">How it Works</div>
        <div className="how-it-work_title_border" />
        <div className="how-it-work_pic">
          <img src={step1} className="how-it-work_pic_item" alt="logo" />
          <img src={step2} className="how-it-work_pic_item" alt="logo" />
          <img src={step3} className="how-it-work_pic_item" alt="logo" />
        </div>
      </div>
    );
}

function Footer(list = FooterMediaIconList) {
  return(
        <div className='media-list'>
        {FooterMediaIconList.map((mediaItem) => {
            return (
              <div className="media-item-wrapper">
                <img
                  src={mediaItem.src}
                  className="media_pic_item"
                  alt="logo"
                />
              </div>
            );
            })}
        </div>
    );
}

function Index() {
    return (
        <div>
            <Header />
            <MainTitle />
            <HowItWork />
            <Footer />
        </div>)
}

export default Index;
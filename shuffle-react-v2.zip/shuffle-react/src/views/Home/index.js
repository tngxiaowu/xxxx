import './index.css';
import HowItWork from '../../components/HowItWork';
import Footer from '../../components/Footer';
import logo from "../../assets/img/logo-with-name.png";
// import videoSrc from "../../assets/img/TEYA-VIDEO.mp4";
import headerGif from '../../assets/img/image-header-2.gif';

const MainMenuList = [
  {
    name: "IDO",
    key: "1",
  },
  {
    name: "Protocol",
    key: "2",
  },
  {
    name: "ERC Bridge",
    key: "3",
  },
  {
    name: "Contact",
    key: "4",
  },
];

const DefaultWalletList = [
  {
    name: "wallet 1",
    key: "1",
  },
  {
    name: "wallet 2",
    key: "2",
  },
];



function MenuItem({ menu }) {
    return (
      <div className='menu'>
        <div className="menu-item">{menu.name}</div>
      </div>
    );    
}

function WalletItem({ wallet }) {
  return (
    <div className='wallet'>
      <div className="wallet-item">{wallet.name}</div>
    </div>
  );
}

function Header({ menus = MainMenuList, walletList = DefaultWalletList }) {
    return (
      <div className="header-view">
        <div className="header-menu">
          {menus.map((menu) => {
            return <MenuItem menu={menu} />;
          })}
        </div>
        <div className="header-logo">
          <img src={logo} alt="logo" />
        </div>
        <div className="header-wallet">{walletList.map((wallet) => {
          return <WalletItem wallet={wallet} />;
        })}</div>
      </div>
    );
}

function MainPic() {
  return (
    <div className="main-pic">
      <div className="main-pic_left">
        {/* <video autoplay={true} width="400" height="400" >
          <source src={videoSrc} type="video/mp4" >
          </source>
        </video> */}
        <img className="main-pic_left_gif" src={headerGif} />
      </div>
      <div className="main-pic_right">
        <div className="main-pic_right_title">BRC20 DEX Teya Swap First</div>
        <div className="main-pic_right_description">
          <div className="main-pic_right_description_l">
          <svg width="84" height="10" viewbox="0 0 84 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 4.25C0.585786 4.25 0.25 4.58579 0.25 5C0.25 5.41421 0.585786 5.75 1 5.75L1 4.25ZM84 5.00001L76.5 0.669879L76.5 9.33013L84 5.00001ZM1 5.75L77.25 5.75001L77.25 4.25001L1 4.25L1 5.75Z" fill="currentColor"></path>
                      </svg>
          </div>
          <div className="main-pic_right_description_r">
            {" "}
            Teya swap is an innovative BRC dex that lets you easily trade BRC-20
            tokens, based on the Ordinal protocol, unlocking the infinite future
            of the BRC defi ecosystem.{" "}
          </div>
        </div>
        <div className="main-pic_ido">
          <div className="main-pic_ido_btn">IDO PLAN</div>
        </div>
      </div>
    </div>
  );
}

const picSrc = 'https://www.teyaswap.com/saturn-assets/images/headers/star-header-right-bottom.png';
function WhiteList() {
  return (
    <div className='white-list'>
      <div className='black-box'>
        <div className='black-box_inner'>
          <div className='black-box_inner_left'>
            <div className='black-box_inner_left_text'>
              Sign up for our 
            </div>
            <div className='black-box_inner_left_text'>
            Whitelist
            </div>
          </div>
          <div className='black-box_inner_right'>
            <div className='black-box_inner_right_text'>
              Get insider access to our company by subscribing to our newsletter and stay informed about our products, services, and initiatives.
            </div>
            <div className='black-box_inner_right_input'>
              <input />
              <div className='black-box_inner_right_subscribe'> Subscribe </div>
            </div>
            <div className='black-box_inner_right_b_text'>
              We care about your data in our privacy policy
            </div>
          </div>
        </div>

      </div>
    
    </div>)
}




function Home() {
    return (<>
        <Header />
        <MainPic />
        <WhiteList />
        <HowItWork/>
        <Footer />
    </>
    )
}

export default Home;
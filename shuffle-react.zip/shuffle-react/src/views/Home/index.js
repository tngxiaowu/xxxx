import './index.css';
import HowItWork from '../../components/HowItWork';
import logo from "../../assets/img/logo-with-name.png";
// import logoPic from "../../assets/img/logo-with-name.png";

const MainMenuList = [
  {
    name: "IDO",
    key: "1",
  },
  {
    name: "Protocol",
    key: "2",
  },
  {
    name: "ERC Bridge",
    key: "3",
  },
  {
    name: "Contact",
    key: "4",
  },
];

const DefaultWalletList = [
  {
    name: "wallet 1",
    key: "1",
  },
  {
    name: "wallet 2",
    key: "2",
  },
];



function MenuItem({ menu }) {
    return (
      <div className='menu'>
        <div className="menu-item">{menu.name}</div>
      </div>
    );    
}

function WalletItem({ wallet }) {
  return (
    <div className='wallet'>
      <div className="wallet-item">{wallet.name}</div>
    </div>
  );
}

function Header({ menus = MainMenuList, walletList = DefaultWalletList }) {
    return (
      <div className="header-view">
        <div className="header-menu">
          {menus.map((menu) => {
            return <MenuItem menu={menu} />;
          })}
        </div>
        <div className="header-logo">
          <img src={logo} alt="logo" />
        </div>
        <div className="header-wallet">{walletList.map((wallet) => {
          return <WalletItem wallet={wallet} />;
        })}</div>
      </div>
    );
}

function MainPic() {
  return (
    <div className="main-pic">
      <div className="main-pic_left">PIC</div>
      <div className="main-pic_right">
        <div className="main-pic_right_title">BRC20 DEX Teya Swap First</div>
        <div className="main-pic_right_description">
          <div className="main-pic_right_description_l"> 1 </div>
          <div className="main-pic_right_description_r">
            {" "}
            Teya swap is an innovative BRC dex that lets you easily trade BRC-20
            tokens, based on the Ordinal protocol, unlocking the infinite future
            of the BRC defi ecosystem.{" "}
          </div>
        </div>
        <div className="main-pic_ido">
          <div className="main-pic_ido_btn">IDO PLAN</div>
        </div>
      </div>
    </div>
  );
}




function Home() {
    return (<>
        <Header />
        <MainPic />
        <HowItWork/>
    </>
    )
}

export default Home;
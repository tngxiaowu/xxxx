import step1 from "../../assets/img/how-it-works-1.png";
import step2 from "../../assets/img/how-it-works-2.png";
import step3 from "../../assets/img/how-it-works-3.png";
import './index.css';

function HowItWork() {
  return (
    <div className="how-it-work">
      <div className="how-it-work_title">How it Works</div>
      <div className="how-it-work_title_border" />
      <div className="how-it-work_pic">
        <img src={step1} className="how-it-work_pic_item" alt="logo" />
        <img src={step2} className="how-it-work_pic_item" alt="logo" />
        <img src={step3} className="how-it-work_pic_item" alt="logo" />
      </div>
    </div>
  );
}

export default HowItWork;
